
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kou3141',
  applicationName: 'seknot-api',
  appUid: '28P76N625TVkzVBhfN',
  orgUid: 'b6238b1f-df1a-4213-8390-51e0abd4a734',
  deploymentUid: '6aca22e7-1feb-4ca1-9dbe-ca58849f97b9',
  serviceName: 'seknotApi',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'seknotApi-dev-walletService', timeout: 6 };

try {
  const userHandler = require('./src/functions/WalletService/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}